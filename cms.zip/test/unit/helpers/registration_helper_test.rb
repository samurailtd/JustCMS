require 'test_helper'

class RegistrationHelperTest < ActionView::TestCase
end
