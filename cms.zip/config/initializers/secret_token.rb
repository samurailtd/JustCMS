# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Cms::Application.config.secret_token = 'be59fcd1d18adae3a22f0c923e27cf3482e3e272758da6cee189df772796671d6524426427a3a00a59558a9061df6a2a8d9c46734fe6945d397dec95ffbe4283'
