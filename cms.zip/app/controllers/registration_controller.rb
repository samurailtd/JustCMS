class RegistrationController < ApplicationController
  def index
  puts "hello andr"
  end
end
